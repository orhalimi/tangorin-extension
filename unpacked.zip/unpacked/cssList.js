////export cssList = {
//  popupCss: `.ex-popup  {
//  width: 27%;
//  background-color: #f9f9eb;
//  position: fixed;
//  right:2%;
//  top:20%;
//  padding: 0px 0px 4px 0px;
//  border: 1px solid silver;
//  border-radius:12px;
//  z-index:5}`,
//
//  closeBtnCss: `.ex-popup a {
// color: #0060B6;
// text-decoration: none;
// float:right;
// line-height: 25px;
//
// display:block;
// margin-right:11px;
//}
//
//.ex-popup a:hover{
//  color: green;
//  text-decoration: none;
//
//}
//.ex-popup a:active{
//  color: red;
//  text-decoration: none;
//}`,
//
//  textareaCss: `.ex-popup textarea{
//  clear:both;
//  display:block;
//  width: 94%;
//  border: 1;
//  margin:  10px auto;
//  padding: 1px;
//  border-radius:4px;
//}`
//};
